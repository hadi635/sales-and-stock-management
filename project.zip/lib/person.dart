class person{
  int id;
  String name;
  String nbtelephone;


person(this.id,this.name,this.nbtelephone);

}
